<?php

$filePath=ROOT_PATH.'contents/plugins/firemanga/controller/controlStats.php';

if(file_exists($filePath))
{
	include($filePath);
}


?>